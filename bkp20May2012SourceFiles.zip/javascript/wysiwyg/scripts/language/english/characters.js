function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "HTML Code";
    document.getElementById("btnClose").value = "close";
    }
function writeTitle()
    {
    document.write("<title>Special Characters</title>")
    }