function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "Oletko varma, ett\u00E4 haluat poistaa t\u00E4m\u00E4n kansion?";

    document.getElementById("btnClose").value = "Sulje";
    document.getElementById("btnDelete").value = "Poista";
    }
function writeTitle()
    {
    document.write("<title>Poista kansio</title>")
    }
