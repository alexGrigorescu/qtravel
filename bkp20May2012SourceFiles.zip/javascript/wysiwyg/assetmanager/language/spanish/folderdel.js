function loadTxt()
    {
    document.getElementById("txtLang").innerHTML = "Est\u00E1 seguro que quiere borrar la carpeta?";

    document.getElementById("btnClose").value = "Cerrar";
    document.getElementById("btnDelete").value = "Borrar";
    }
function writeTitle()
    {
    document.write("<title>Borrar Carpeta</title>")
    }
