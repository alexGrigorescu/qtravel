<?php
	$GATE_URL = 'gate.welwel.ro/';
?>