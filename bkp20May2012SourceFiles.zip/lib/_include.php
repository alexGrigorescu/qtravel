<?
	require "lib/smarty/Smarty.class.php";
	
	require "lib/captcha.php";
	require "lib/dt.php";
	require "lib/db_query.php";
	require "lib/db_table.php";
	require "lib/errors.php";
	require "lib/files.php";
	require "lib/template.php";
	require "lib/webobject.php";
	require "lib/grid.php";
	require "lib/form.php";
	require "lib/mail.php";
	require "lib/fpdf.php";
	require "lib/misc.php";
	require "lib/miscu.php";
	
	include_once('lib/SimplePie/simplepie.inc');
	include_once('lib/SimplePie/idn/idna_convert.class.php');
?>
