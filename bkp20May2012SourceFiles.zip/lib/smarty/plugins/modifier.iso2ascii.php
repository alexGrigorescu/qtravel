<?php
/**
 * Smarty plugin
 * @package Smarty
 * @subpackage plugins
 */

function smarty_modifier_iso2ascii($string)
{
    return iso2ascii($string);
}

?>
